

<?php $__env->startSection('content'); ?>
    <div class="bg-light p-5 rounded">
        <?php if(auth()->guard()->check()): ?>
        <h1>Dashboard</h1>
        <p class="lead">Only authenticated users can access this section.</p>
        <a class="btn btn-lg btn-primary" href="https://codeanddeploy.com" role="button">View more tutorials here &raquo;</a>

        <?php
           // dd($data);
        ?>
        <table class="table">
        <thead class="thead-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Company</th>
                <th scope="col">Contact</th>
                <th scope="col">Address1</th>
                <th scope="col">City</th>
                <th scope="col">Country</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="row"><?php echo e($key); ?></td>
                <td scope="col"><?php echo e($user['company']); ?></td>
                <td scope="col"><?php echo e($user['contact']); ?></td>
                <td scope="col"><?php echo e($user['addressline1']); ?></td>
                <td scope="col"><?php echo e($user['city']); ?></td>
                <td scope="col"><?php echo e($user['country']); ?></td>
            </tr> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
        </tbody>
        </table>
        
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
        <h1>Homepage</h1>
        <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rajad\OneDrive\Desktop\laravel\App\resources\views/home/index.blade.php ENDPATH**/ ?>